package PostOfficeProject;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.math.BigInteger;
import java.sql.*;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;


public class Security {		
	
	private static SecureRandom random = new SecureRandom();
	
	// Create a new User
	public void newUser(String empid, String password)throws SQLException{		
		String salt = getSalt();
		byte[] hashCode = hash(password, salt);		
		Connection con = null;
		
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			String addUser = "INSERT INTO POST_USERS " +"VALUES(?, ?, ?, ?)";
			PreparedStatement registerUser = con.prepareStatement(addUser);
			
			registerUser.setString(1, empid);
			registerUser.setString(2, empid);
			registerUser.setString(3, salt);
			registerUser.setBytes(4, hashCode);
			registerUser.executeUpdate();
			
			System.out.println("User added");
			con.close();
		}catch (Exception e) {	
			con.rollback();
			System.out.println(e);
		}		
	}// end of newUser
	
	// Attempt to login a user
	public String loginUser(int empid, String password) throws SQLException{
		String salt;
		Connection con = null;
		
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			String getUserSalt = "SELECT salt FROM POST_USERS WHERE emp_id = ?";
			PreparedStatement findSalt = con.prepareStatement(getUserSalt);
			findSalt.setString(1, Integer.toString(empid));
			ResultSet rs = findSalt.executeQuery();
			rs.next();
			salt = rs.getString("salt");
			
			byte[] hashCode = hash(password, salt);
			
			String findUser = "SELECT role FROM POST_USERS "
					+"JOIN POST_EMPLOYEE USING(emp_id) "
					+"WHERE emp_id = ? AND salt = ? AND hash = ?";			
			PreparedStatement findUserInfo = con.prepareStatement(findUser);
			
			findUserInfo.setString(1, Integer.toString(empid));
			findUserInfo.setString(2, salt);
			findUserInfo.setBytes(3, hashCode);
			
			rs = findUserInfo.executeQuery();
			if(rs.next()){
				System.out.println("Successful login");
				return rs.getString(1);
			}			
			con.close();	
		} catch (Exception e) {	
			con.rollback();
		}		
		System.out.println("Unsuccessful login.");
		return "fail";
	}// end of loginUser
	
	// Helper method to get a database connection
	public static Connection getConnection(){
		Connection con = null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
			"jdbc:oracle:thin:@198.168.52.73:1521:orad11g", "A1542705", "password130");						
		System.out.println("Connected to database");
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}// end of getConnection
	
	//Change a user's password
	public void changePassword(int empid, String newPassword)throws SQLException{
		String salt = getSalt();
		byte[] hashCode = hash(newPassword, salt);		
		Connection con = null;
		
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			String sql = "UPDATE Post_USERS SET salt = ?, hash = ? "
					+ "WHERE emp_id = ?";
			PreparedStatement changePass = con.prepareStatement(sql);
			
			changePass.setString(1, salt);
			changePass.setBytes(2, hashCode);
			changePass.setString(3, Integer.toString(empid));
			changePass.executeUpdate();
			
			System.out.println("Password changed");
			con.close();
		}catch (Exception e) {	
			con.rollback();
			System.out.println(e);
		}		
	}// end of changePassword
	
	//Creates a randomly generated String
	public String getSalt(){
		return new BigInteger(140, random).toString(32);
	}
		
		//Takes a password and a salt a performs a one way hashing on them, returning an array of bytes.
		public byte[] hash(String password, String salt){
			try{
				SecretKeyFactory skf = SecretKeyFactory.getInstance( "PBKDF2WithHmacSHA512" );
		        
				/*When defining the keyspec, in addition to passing in the password and salt, we also pass in
				a number of iterations (1024) and a key size (256). The number of iterations, 1024, is the
				number of times we perform our hashing function on the input. Normally, you could increase security
				further by using a different number of iterations for each user (in the same way you use a different
				salt for each user) and storing that number of iterations. Here, we just use a constant number of
				iterations. The key size is the number of bits we want in the output hash*/ 
				PBEKeySpec spec = new PBEKeySpec( password.toCharArray(), salt.getBytes(), 1024, 256 );

				SecretKey key = skf.generateSecret( spec );
		        byte[] hash = key.getEncoded( );
		        return hash;
	        }catch( NoSuchAlgorithmException | InvalidKeySpecException e ) {
	            throw new RuntimeException( e );
	        }
		}
}// end of MovieSecurity
