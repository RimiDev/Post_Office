package PostOfficeProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.Callable;
import java.util.Date;

import oracle.jdbc.OracleTypes;

public class ClerkActions {

	public void createRegisteredMail(int m, double w, double p, String da,
				String ra, String c, String dc, String rc)throws SQLException{
		Connection  con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
						
			CallableStatement s = con.prepareCall("{call insertRegisteredMail(?,?,?,?,?,?,?,?)}");
			s.setString(1, Integer.toString(m));
			s.setDouble(2, w);
			s.setDouble(3, p);
			s.setString(4, da);
			s.setString(5, ra);
			s.setString(6, c);
			s.setString(7, dc);
			s.setString(8, rc);
			s.execute();
			System.out.println("Mail has been added to system");
			
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of createRegisterdMail
	
	public void createUnregisteredMail(int m, double w, double p, String da,
			String ra, String c, String dc, String rc)throws SQLException{
		
	Connection  con = null;
	try{
		con = getConnection();
		con.setAutoCommit(false);
					
		CallableStatement s = con.prepareCall("{call insertUnregisteredMail(?,?,?,?,?,?,?,?)}");
		s.setString(1, Integer.toString(m));
		s.setDouble(2, w);
		s.setDouble(3, p);
		s.setString(4, da);
		s.setString(5, ra);
		s.setString(6, c);
		s.setString(7, dc);
		s.setString(8, rc);
		s.execute();
		System.out.println("Mail has been added to system");
		
	}catch(Exception e){
		e.printStackTrace();
	}
	con.close();
}// end of createRegisterdMail
	
	public double getShippingCost(double w, String c) throws SQLException{
		
		Connection  con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{? = call postageShippingCost(?,?)}");
			s.registerOutParameter(1, Types.NUMERIC);
			s.setDouble(2, w);
			s.setString(3, c);
			s.execute();
			
			return s.getDouble(1);
					
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
		return 0;
	}
	
	public void registerMailStatus(int m, String st) throws SQLException {
		
		Connection  con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call mailStatusRegistered(?,?)}");
			s.setString(1, Integer.toString(m));
			s.setString(2, st);
			s.execute();
			System.out.println("The status has been changed to: " + st);
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
		
	}// end of registerMailStatus
	
	public void unregisterMailStatus(int m, String st)throws SQLException{
		Connection  con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call mailStatusunRegistered(?,?)}");
			s.setString(1, Integer.toString(m));
			s.setString(2, st);
			s.execute();
			System.out.println("The status has been changed to: " + st);
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of unregisterMailStatus
	
	public void checkRegisteredDistrict(int m, int o)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call mailSentToRegistered(?,?)}");
			s.setString(1, Integer.toString(m));
			s.setString(2, Integer.toString(o));
			s.execute();
			System.out.println("The mail status has been changed accordingly");
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of checkRegisteredDistrict
	
	public void checkUnregisteredDistrict(int m, int o)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call mailSentToUnregistered(?,?)}");
			s.setString(1, Integer.toString(m));
			s.setString(2, Integer.toString(o));
			s.execute();
			System.out.println("The mail status has been changed accordingly");
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of checkRegisteredDistrict

	public void viewMailByRoute(int r)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call viewAllMailByRouteCursor(?,?,?)}");
			s.setString(1, Integer.toString(r));
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.execute();
			
			ResultSet rs = (ResultSet)s.getObject(2);			
			ResultSet rs2 = (ResultSet)s.getObject(3);
			
			System.out.println("Registered mail IDs:");
			while(rs.next()){
				System.out.println();
				System.out.println("id: " +rs.getString(1));
				System.out.println("weight: " +rs.getString(2));
				System.out.println("postage: " +rs.getString(3));
				System.out.println("status: " +rs.getString(4));
				System.out.println("delivery address: " +rs.getString(5));
				System.out.println("return address: " +rs.getString(6));
				System.out.println("delivery country: " +rs.getString(7));
				System.out.println("delivery postal code: " +rs.getString(8));
				System.out.println("return postal code: " +rs.getString(9));
			}
			
			System.out.println("Unregistered mail IDs:");
			while(rs2.next()){
				System.out.println();
				System.out.println("id: " +rs2.getString(1));
				System.out.println("weight: " +rs2.getString(2));
				System.out.println("postage: " +rs2.getString(3));
				System.out.println("status: " +rs2.getString(4));
				System.out.println("delivery address: " +rs2.getString(5));
				System.out.println("return address: " +rs2.getString(6));
				System.out.println("delivery country: " +rs2.getString(7));
				System.out.println("delivery postal code: " +rs2.getString(8));
				System.out.println("return postal code: " +rs2.getString(9));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of viewMailByRoute
	
	public void viewMailByPostalCode(String p)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call viewAllMailByPostalCodeCursor(?,?,?)}");
			s.setString(1, p);
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.execute();
			
			ResultSet rs = (ResultSet)s.getObject(2);			
			ResultSet rs2 = (ResultSet)s.getObject(3);
			
			System.out.println("Registered mail IDs:");
			while(rs.next()){
				System.out.println();
				System.out.println("id: " +rs.getString(1));
				System.out.println("weight: " +rs.getString(2));
				System.out.println("postage: " +rs.getString(3));
				System.out.println("status: " +rs.getString(4));
				System.out.println("delivery address: " +rs.getString(5));
				System.out.println("return address: " +rs.getString(6));
				System.out.println("delivery country: " +rs.getString(7));
				System.out.println("delivery postal code: " +rs.getString(8));
				System.out.println("return postal code: " +rs.getString(9));
			}
			
			System.out.println("Unregistered mail IDs:");
			while(rs2.next()){
				System.out.println();
				System.out.println("id: " +rs2.getString(1));
				System.out.println("weight: " +rs2.getString(2));
				System.out.println("postage: " +rs2.getString(3));
				System.out.println("status: " +rs2.getString(4));
				System.out.println("delivery address: " +rs2.getString(5));
				System.out.println("return address: " +rs2.getString(6));
				System.out.println("delivery country: " +rs2.getString(7));
				System.out.println("delivery postal code: " +rs2.getString(8));
				System.out.println("return postal code: " +rs2.getString(9));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of viewMailByPostalCode
	
	
	public void viewMailByAddress(String a)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call viewAllMailByAddressCursor(?,?,?)}");
			s.setString(1, a);
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.execute();
			
			ResultSet rs = (ResultSet)s.getObject(2);			
			ResultSet rs2 = (ResultSet)s.getObject(3);
			
			System.out.println("Registered mail IDs:");
			while(rs.next()){
				System.out.println();
				System.out.println("id: " +rs.getString(1));
				System.out.println("weight: " +rs.getString(2));
				System.out.println("postage: " +rs.getString(3));
				System.out.println("status: " +rs.getString(4));
				System.out.println("delivery address: " +rs.getString(5));
				System.out.println("return address: " +rs.getString(6));
				System.out.println("delivery country: " +rs.getString(7));
				System.out.println("delivery postal code: " +rs.getString(8));
				System.out.println("return postal code: " +rs.getString(9));
			}
			
			System.out.println("Unregistered mail IDs:");
			while(rs2.next()){
				System.out.println();
				System.out.println("id: " +rs2.getString(1));
				System.out.println("weight: " +rs2.getString(2));
				System.out.println("postage: " +rs2.getString(3));
				System.out.println("status: " +rs2.getString(4));
				System.out.println("delivery address: " +rs2.getString(5));
				System.out.println("return address: " +rs2.getString(6));
				System.out.println("delivery country: " +rs2.getString(7));
				System.out.println("delivery postal code: " +rs2.getString(8));
				System.out.println("return postal code: " +rs2.getString(9));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of viewMailByaddress
	
	
	
	// Helper method to get a database connection
	public static Connection getConnection(){
		Connection con = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
			"jdbc:oracle:thin:@198.168.52.73:1521:orad11g", "A1542705", "password130");						
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}// end of getConnection
}// end of ClerkActions
