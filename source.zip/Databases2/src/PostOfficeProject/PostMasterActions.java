package PostOfficeProject;

import java.sql.Connection;
import java.sql.DriverManager;

import oracle.jdbc.OracleTypes;

import java.sql.*;

public class PostMasterActions {
	
	public void viewNonOccupiedRoutes() throws SQLException{
		Connection con = null;
		try { 
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call viewNonOccupiedRoutes(?)}");
			s.registerOutParameter(1, OracleTypes.CURSOR);
			s.execute();
			ResultSet today = (ResultSet)s.getObject(1);
				while (today.next()){
					System.out.println(today.getString(1));
				}
		} catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}
	
	public void createEmptyRoute(String n) throws SQLException{
		Connection con = null;
		try {
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call createEmptyRoute(?)}");
		s.setString(1, n);
		s.execute();
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}
	
	public void addPostalCodeFromRoute(int r, String p) throws SQLException{
		Connection con = null;
		try {
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call addPostalCodeFromRoute(?,?)}");
			s.setString(1, Integer.toString(r));
			s.setString(2, p);
			s.execute();
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}
	
	public void removePostalCodeFromRoute(String p) throws SQLException{
		Connection con = null;
		try {
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call removePostalCodeFromRoute(?)}");
			s.setString(1, p);
			s.execute();
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}
	
	public void addEmployee(int e, String f, String l, String r, String p, String em) throws SQLException{
		Connection con = null;
		try { 
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call addEmployee(?,?,?,?,?,?)}");
			s.setString(1, Integer.toString(e));
			s.setString(2, f);
			s.setString(3, l);
			s.setString(4, r);
			s.setString(5, p);
			s.setString(6, em);
			s.execute();
		}catch(Exception e3){
			e3.printStackTrace();
		}
		con.close();
	}
	
	public void removeEmployee(int e) throws SQLException{
		Connection con = null;
		try {
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call removeEmployee(?)}");
			s.setString(1, Integer.toString(e));
			s.execute();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		con.close();
	}
	
	public void setUpRoute(int e, int v) throws SQLException{
		Connection con = null;
		try { 
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call setUpRoute(?,?)}");
			s.setString(1, Integer.toString(e));
			s.setString(2, Integer.toString(v));
			s.execute();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		con.close();
	}
	
	public void modifyVehicle(int v, String s1) throws SQLException{
		Connection con = null;
		try {
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call modifyVehicleStatus(?,?)}");
			s.setString(1, Integer.toString(v));
			s.setString(2, s1);
			s.execute();
		}catch(Exception e){
			e.printStackTrace();
		}
		con.close();
	}
	
	
	
	
	// Helper method to get a database connection
	public static Connection getConnection(){
		Connection con = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
			"jdbc:oracle:thin:@198.168.52.73:1521:orad11g", "A1542705", "password130");						
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}// end of getConnection
}// end of PostMasterActions
