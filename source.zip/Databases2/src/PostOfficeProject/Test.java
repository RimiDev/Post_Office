package PostOfficeProject;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class Test {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		Security s = new Security();
		CarrierActions car = new CarrierActions();
		ClerkActions cal = new ClerkActions();
		
		// populate the users table with their respective employee id
		populateUsers();
		try{
			// Security actions
			
			//s.loginUser(1, "Lewes");
			//s.loginUser(10, "Bunnie");
			//s.loginUser(20, "Xylina");
			
			// Actions for carriers
			//car.getRoutes(1); //1 and 11			
			//car.getVehicle(5); //3
			//car.getMailLoad(1);
			//car.getMailByRoute("1");
			//car.getMailByCode(2, "H8N 8T1");
			//car.getMailByBuilding(2, "2 Cherokee Place"); // registered = 5
			//car.markRegisteredDeliver(3);
			//car.startRoute(2);
			//car.finishRoute(2);
			//car.undeliverableRegisteredMail(2);
			//car.undeliverableUnregisteredMail(2);
			
			//s.changePassword(1, "testing");
			//s.loginUser(1, "Lewes"); //Fail
			//s.loginUser(1, "testing"); //success
			
			//Unique actions for Clerks			
			//cal.createRegisteredMail(100, 100.00, 1.80, "test", "test", "canada", "H8N 9T1", "H8N 3C4");
			//cal.createUnregisteredMail(101, 100.00, 1.80, "test2", "test2", "canada", "H8N 9T1", null);
			//System.out.println(cal.getShippingCost(100.00, "canada")); //1.80
			//cal.registerMailStatus(2, "loaded");
			//cal.unregisterMailStatus(2, "loaded");
			//cal.checkRegisteredDistrict(1, 1); // should do nothing
			//cal.checkRegisteredDistrict(12, 1); // should sent to airport
			//cal.checkUnregisteredDistrict(1, 1); // should change nothing
			//cal.checkUnregisteredDistrict(10, 1); // should sent mail to airport
			//cal.viewMailByRoute(1);
			//cal.viewMailByPostalCode("H8N 3C4");
			//cal.viewMailByAddress("3677 Elmside Avenue");
			
			
		}catch(Exception e){
			System.out.println("OOPS");
		}

	}// end of main
	
	public static void populateUsers(){
		Security s = new Security();
		
		try {
			s.newUser("1", "Lewes");
			s.newUser("2", "Lindsey");
			s.newUser("3", "Dollie");
			s.newUser("4", "Toby");
			s.newUser("5", "Blythe");
			s.newUser("6", "Jolie");
			s.newUser("7", "Hagan");
			s.newUser("8", "Lorie");
			s.newUser("9", "Cole");
			s.newUser("10", "Bunnie");
			s.newUser("11", "Dasya");
			s.newUser("12", "Jennifer");
			s.newUser("13", "Silvain");
			s.newUser("14", "Jilleen");
			s.newUser("15", "Camellia");
			s.newUser("16", "Cariotta");
			s.newUser("17", "Fanni");
			s.newUser("18", "Saunders");
			s.newUser("19", "Corabel");
			s.newUser("20", "Xylina");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}// end of class
