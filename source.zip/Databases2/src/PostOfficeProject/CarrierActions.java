package PostOfficeProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.Callable;
import java.util.Date;

import oracle.jdbc.OracleTypes;

public class CarrierActions {

	public String getSchedule(int empId)throws SQLException{
		Connection con = null;
		CallableStatement cstmt = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			cstmt = con.prepareCall( "{? = call getSchedule(?)}");
			cstmt.registerOutParameter(1, Types.VARCHAR);
			cstmt.setString(2, Integer.toString(empId));
			cstmt.execute();
			return cstmt.getString(1);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			cstmt.close();
			con.close();
		}
		return "";
	}
	
	public void getRoutes(int empId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getMailRoutesCursor(?,?)}");
			s.setString(1, Integer.toString(empId));
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(2);			
			
			System.out.println("Route Id:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}								
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}

	public void getVehicle(int empId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getVehicleCursor(?,?)}");
			s.setString(1, Integer.toString(empId));
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(2);			
			
			System.out.println("Vehicle Id:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}								
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}

	public void getMailLoad(int empId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getMailToDeliverCursor(?,?,?)}");
			s.setString(1, Integer.toString(empId));
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(2);			
			ResultSet rs2 = (ResultSet)s.getObject(3);
			
			System.out.println("Unregistered mail IDs:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}
			
			System.out.println("Registered mail IDs:");
			while(rs2.next()){
				System.out.println(rs2.getString(1));
			}
						
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}// end of getMailLoad
	
	public void getMailByRoute(String routeId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getMailByRouteCursor(?,?,?)}");
			s.setString(1, routeId);
			s.registerOutParameter(2, OracleTypes.CURSOR);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(2);			
			ResultSet rs2 = (ResultSet)s.getObject(3);
			
			System.out.println("Unregistered mail IDs:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}
			
			System.out.println("Registered mail IDs:");
			while(rs2.next()){
				System.out.println(rs2.getString(1));
			}
						
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}// end of getMailByRou{

	public void getMailByCode(int empId, String pc)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getDeliveryCodeCursor(?,?,?,?)}");
			s.setString(1, Integer.toString(empId));
			s.setString(2, pc);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.registerOutParameter(4, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(3);			
			ResultSet rs2 = (ResultSet)s.getObject(4);
			
			System.out.println("Registered mail IDs:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}
			
			System.out.println("Unregistered mail IDs:");
			while(rs2.next()){
				System.out.println(rs2.getString(1));
			}
						
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}// end of getMailbyCode
	
	public void getMailByBuilding(int empId, String address)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call getMaillToDeliverAddressCursor(?,?,?,?)}");
			s.setString(1, Integer.toString(empId));
			s.setString(2, address);
			s.registerOutParameter(3, OracleTypes.CURSOR);
			s.registerOutParameter(4, OracleTypes.CURSOR);
			s.execute();
			ResultSet rs = (ResultSet)s.getObject(3);			
			ResultSet rs2 = (ResultSet)s.getObject(4);
			
			System.out.println("Registered mail IDs:");
			while(rs.next()){
				System.out.println(rs.getString(1));
			}
			
			System.out.println("Unregistered mail IDs:");
			while(rs2.next()){
				System.out.println(rs2.getString(1));
			}
						
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		con.close();
	}// end of getMailByBuiling
	
	public void markRegisteredDeliver(int mailId) throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call markRegisteredMail(?)}");
			s.setString(1, Integer.toString(mailId));
			s.execute();
			System.out.println("Mail has been marked as delivered");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of markRegisteredDeliver
	
	public void startRoute(int routeId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call startRoute(?)}");
			s.setString(1, Integer.toString(routeId));
			s.execute();
			System.out.println("Route has Started");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of startRoute
	
	public void finishRoute(int routeId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call completeRoute(?)}");
			s.setString(1, Integer.toString(routeId));
			s.execute();
			System.out.println("Route has Finished");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of finishRoute
	
	public void undeliverableRegisteredMail(int mailId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call undeliverableRegisteredMail(?)}");
			s.setString(1, Integer.toString(mailId));
			s.execute();
			System.out.println("Mail has been marked as undeliverable");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of undeliverableRegisteredMail
	
	public void undeliverableUnregisteredMail(int mailId)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			CallableStatement s = con.prepareCall("{call undeliverableUnregisteredMail(?)}");
			s.setString(1, Integer.toString(mailId));
			s.execute();
			System.out.println("Mail has been marked as delivered");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of undeliverableUnregisteredMail
		
	public void unableToWork(int empId, String offDay)throws SQLException{
		Connection con = null;
		try{
			con = getConnection();
			con.setAutoCommit(false);
			
			SimpleDateFormat df = new SimpleDateFormat("dd-mm-yyyy");
			Date date1 = df.parse(offDay);
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());
			
			CallableStatement s = con.prepareCall("{call carrierDayOff(?,?)}");
			s.setString(1, Integer.toString(empId));
			s.setDate(2, sqlDate);
			s.execute();
			System.out.println("Day off registered successfully");
		}catch (Exception e){
			e.printStackTrace();
		}
		con.close();
	}// end of unableToWork
		
	// Helper method to get a database connection
	public static Connection getConnection(){
		Connection con = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
			"jdbc:oracle:thin:@198.168.52.73:1521:orad11g", "A1542705", "password130");						
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}// end of getConnection
}// end of CarrierActions
