package PostOfficeProject;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import labs9_10.CustomerActions;
import labs9_10.MovieSecurity;

public class Application {

	// Read user input
	private static Scanner scanner = new Scanner(System.in); 
	private static int eid;
	
	public static void main(String[] args) {
			System.out.println("Welcome to the Post Office Database.");
			loginUser();
	}// end of main

	private static void loginUser(){
		Security secure = new Security();
		System.out.println("Please enter your Employee Id.");
		String employeeId = scanner.next();
		eid = Integer.parseInt(employeeId); 
		System.out.println("Please enter your password.");
		String password = scanner.next();	
		
		try{
			String roleResult = secure.loginUser(eid, password);
			System.out.println(roleResult);
			if(roleResult.equalsIgnoreCase("carrier")){
				carrierInteractions();
			} else if(roleResult.equalsIgnoreCase("clerk")){
				clerkInteractions();
			} else if(roleResult.equalsIgnoreCase("postmaster")){
				postmasterInteractions();
			}else{
				System.out.println("User does not exist.");
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}// end of loginUser
	
	private static void createUser(){
		Security secure = new Security();	
		
		System.out.println("Enter your employee Id");
		String empid = scanner.next();
		System.out.println("Enter your wanted password");
		String password = scanner.next();
		
		try{
			secure.newUser(empid, password);
		}catch(SQLException e){
			e.printStackTrace();
		}
	}// end of createUser

	private static void carrierInteractions(){
		Security s = new Security();
		CarrierActions ca = new CarrierActions();
		System.out.println("What would you like to do.\n"
					+"1 - View your Routes and Vehicle\n"
					+"2 - View Mail you must deliver\n"
					+"3 - View mail to be delivered by Postalcode in route\n"
					+"4 - View all mail addressed to a bulding\n"
					+"5 - Mark registered mail as delivered\n"
					+"6 - Mark route as started\n"
					+"7 - Mark mail route as completed\n"
					+"8 - Mark  registered mail as undeliverable\n"
					+"9 - Mark  unregistered mail as undeliverable\n"
					+"10 - Mark yourself as unable to work on a day\n"
					+"11 - Modify your password\n");
		
		int choice = scanner.nextInt();
		while(choice < 1 && choice > 11){
			System.out.println("Please enter a valid choice");
			choice = scanner.nextInt();
		}				
		scanner.nextLine(); // consume newline left-over
		
		switch(choice){
		case 1 : 
			try{
				ca.getRoutes(eid);
				ca.getVehicle(eid);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		case 2 : 
			try{
				ca.getMailLoad(eid);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		case 3 : 
			try{
				System.out.println("Enter the postal code");
				String code = scanner.next();
				ca.getMailByCode(eid, code);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		case 4 : 
			try{
				System.out.println("Enter the building address");
				String add = scanner.next();
				ca.getMailByBuilding(eid, add);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		case 5 : 
			System.out.println("What is the registered mail id");
			int mailId = scanner.nextInt();
			try {
				ca.markRegisteredDeliver(mailId);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 7 : 
			System.out.println("what is the route id");
			int rid2 = scanner.nextInt();
			try {
				ca.finishRoute(rid2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 6 : 
			System.out.println("what is the route id");
			int rid3 = scanner.nextInt();
			try {
				ca.startRoute(rid3);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 8 : 
			System.out.println("What is the mail id");
			int mid = scanner.nextInt();
			try {
				ca.undeliverableRegisteredMail(mid);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 9 : 
			System.out.println("What is the mail id");
			int mid2 = scanner.nextInt();
			try {
				ca.undeliverableUnregisteredMail(mid2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 10 : 
			System.out.println("What day do you want off (DD-MM-YYYY)");
			String od = scanner.next();
			try {
				ca.unableToWork(eid, od);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		break;
		case 11 : 
			try{
				System.out.println("What is your new password");
				String pass = scanner.next();
				s.changePassword(eid, pass);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		}
	}// end of carrierInteractions
	
	private static void clerkInteractions(){
		Security s = new Security();
		ClerkActions ca = new ClerkActions();
		System.out.println("What would you like to do.\n"
				+"1 - Add Registered mail to the system\n"
				+"2 - Add unregistered mail to the system\n"
				+"3 - Get shipping cost\n"
				+"4 - Change registered mail status\n"
				+"5 - Change unregistered mail status\n"
				+"6 - Send registered mail away is needed\n"
				+"7 - Send unregistered mail away is needed\n"
				+"8 - View all mail by route\n"
				+"9 - View all mail by postal code\n"
				+"10 - View all mail by address\n"
				+"11 - Modify your password");
		
		int choice = scanner.nextInt();
		while(choice < 1 && choice > 11){
			System.out.println("Please enter a valid choice");
			choice = scanner.nextInt();
		}				
		scanner.nextLine(); // consume newline left-over
		
		switch(choice){
		case 1 : 
				System.out.println("Enter mail id.");
				int m = scanner.nextInt();
				System.out.println("Enter weight.");
				double w = scanner.nextDouble();
				System.out.println("Enter postage.");
				double p = scanner.nextDouble();
				System.out.println("Enter delivery address.");
				String da = scanner.next();
				System.out.println("Enter return address.");
				String ra = scanner.next();
				System.out.println("Enter delivery country.");
				String dc = scanner.next();
				System.out.println("Enter delivery code.");
				String dco = scanner.next();
				System.out.println("Enter return code.");
				String rc = scanner.next();
				
			try {
				ca.createRegisteredMail(m, w, p, da, ra, dc, dco, rc);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		break;
		case 2 : 
			System.out.println("Enter mail id.");
			int m2 = scanner.nextInt();
			System.out.println("Enter weight.");
			double w2 = scanner.nextDouble();
			System.out.println("Enter postage.");
			double p2 = scanner.nextDouble();
			System.out.println("Enter delivery address.");
			String da2 = scanner.next();
			System.out.println("Enter return address.");
			String ra2 = scanner.next();
			System.out.println("Enter delivery country.");
			String dc2 = scanner.next();
			System.out.println("Enter delivery code.");
			String dco2 = scanner.next();
			System.out.println("Enter return code.");
			String rc2 = scanner.next();
			
		try {
			ca.createUnregisteredMail(m2, w2, p2, da2, ra2, dc2, dco2, rc2);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		break;
		case 3 : 
			System.out.println("Enter the weight: ");
			double w3 = scanner.nextDouble();
			System.out.println("Enter the country: ");
			String c = scanner.next();
			
			try { 
				System.out.println("The cost is: " + ca.getShippingCost(w3, c));
			}catch (SQLException e) {
				e.printStackTrace();
			}
			
		break;
		case 4 : 
			System.out.println("Enter the mail ID: ");
			int s3 = scanner.nextInt();
			System.out.println("Enter the status: ");
			String s4 = scanner.next();
			
			try {
				ca.registerMailStatus(s3, s4);
			}catch(SQLException e){
				e.printStackTrace();
			}
			
		break;
		case 5 : 
			System.out.println("Enter the mail ID: ");
			int s5 = scanner.nextInt();
			System.out.println("Enter the status: ");
			String s6 = scanner.next();			 
			try {
				ca.unregisterMailStatus(s5, s6);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 6 : 
			System.out.println("Enter the mail id");
			int m3 = scanner. nextInt();
			System.out.println("Enter the office id");
			int o1 = scanner. nextInt();
			try{
				ca.checkRegisteredDistrict(m3, o1);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 7 : 
			System.out.println("Enter the mail id");
			int m4 = scanner. nextInt();
			System.out.println("Enter the office id");
			int o2 = scanner. nextInt();
			try{
				ca.checkUnregisteredDistrict(m4, o2);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 8 : 
			System.out.println("Enter the route id");
			int route = scanner.nextInt();
			try{
				ca.viewMailByRoute(route);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 9 : 
			System.out.println("Enter the Postal code (??? ???) capital letters");
			String code = scanner.next();
			try{
				ca.viewMailByPostalCode(code);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 10 : 
			System.out.println("Enter the Address, case-sensitive");
			String address = scanner.next();
			try{
				ca.viewMailByPostalCode(address);
			}catch(SQLException e){
				e.printStackTrace();
			}
		break;
		case 11 : 
			try{
				System.out.println("What is your new password");
				String pass = scanner.next();
				s.changePassword(eid, pass);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;}
	}// end of clerkInteractions
	
	private static void postmasterInteractions(){
		Security s = new Security();
		PostMasterActions pa = new PostMasterActions();
		System.out.println("Here are the routes being run.");
		try {
			pa.viewNonOccupiedRoutes();
		} catch (SQLException e5) {
			e5.printStackTrace();
		}
		System.out.println("What would you like to do.\n"
				+"1 - View All clerk options\n"
				+"2 - Add postal code from existing route\n"
				+"3 - Remove postal code from existing route\n"
				+"4 - Add an employee\n"
				+"5 - Remove an employee\n"
				+"6 - Modify a vehicle's status\n"
				+"7 - Modify your password\n"
				);
		int choice = scanner.nextInt();
		while(choice < 1 && choice > 8){
			System.out.println("Please enter a valid choice");
			choice = scanner.nextInt();
		}				
		scanner.nextLine(); // consume newline left-over
		
		switch(choice){
		case 1 : 
			clerkInteractions();
		break;
		case 2 :
			System.out.println("Enter the route ID: ");
			int rid = scanner.nextInt();
			System.out.println("Enter the postal code: ");
			String p = scanner.next();
			
			try {
				pa.addPostalCodeFromRoute(rid, p);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
		break;
		case 3 :
			System.out.println("Enter the postal code: ");
			String p1 = scanner.next();
			
			try {
				pa.removePostalCodeFromRoute(p1);
			} catch (SQLException e){
				e.printStackTrace();
			}
			
		break;
		case 4 :
			System.out.println("Enter the employee ID: ");
			int e2 = scanner.nextInt();
			System.out.println("Enter the first name: ");
			String fn = scanner.next();
			System.out.println("Enter the last name: ");
			String ln = scanner.next();
			System.out.println("Enter the role: ");
			String r = scanner.next();
			System.out.println("Enter the phone number: ");
			String pn = scanner.next();
			System.out.println("Enter the email: ");
			String em = scanner.next();
			
			try {
				pa.addEmployee(e2, fn, ln, r, pn, em);
				System.out.println("Successfully added the employee");
			} catch (SQLException e3){
				e3.printStackTrace();
			}
		break;
		case 5 : 
			System.out.println("Enter the employee ID: ");
			int e4 = scanner.nextInt();
			
			try {
				pa.removeEmployee(e4);
				System.out.println("Successfully removed the employee");
			} catch (SQLException e){
				e.printStackTrace();
			}
		break;
		case 6 :
			System.out.println("Enter the vehicle ID: ");
			int v3 = scanner.nextInt();
			System.out.println("Enter the status of the vehicle: ");
			String st = scanner.next();
			
			try {
				pa.modifyVehicle(v3, st);
				System.out.println("Successfully modified the vehicle status to: " + st);
			} catch (SQLException e){
				e.printStackTrace();
			}
		break;
		case 7 : 
			try{
				System.out.println("What is your new password");
				String pass = scanner.next();
				s.changePassword(eid, pass);
			}catch(Exception e){
				e.printStackTrace();
			}
		break;
		}
	}
}// end of class
